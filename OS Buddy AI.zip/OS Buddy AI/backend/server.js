
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { MongoClient } from "mongodb";
import {
  analyzeIssue,
  generateCodeFix,
  generateTestPlan,
} from "./aiService.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const client = new MongoClient(
  process.env.MONGODB_URI || "mongodb://127.0.0.1:27017"
);

app.use(cors());
app.use(express.json({ limit: "30kb" }));

let db;

app.get("/", (req, res) => {
  res.json({ message: "OpenSource Buddy AI backend is running" });
});

app.get("/api/health", (req, res) => {
  res.json({
    server: "running",
    database: db ? "connected" : "disconnected",
    aiConfigured: Boolean(process.env.GROQ_API_KEY),
    githubConfigured: Boolean(process.env.GITHUB_TOKEN),
  });
});

function validLanguage(language) {
  return ["English", "Hindi + English"].includes(language);
}

function safeIssue(issue) {
  if (!issue || typeof issue !== "object" || Array.isArray(issue)) {
    throw Object.assign(new Error("A valid issue object is required."), {
      status: 400,
    });
  }

  if (typeof issue.title !== "string" || !issue.title.trim()) {
    throw Object.assign(new Error("Issue title is required."), {
      status: 400,
    });
  }

  return {
    title: issue.title.trim().slice(0, 500),
    body: typeof issue.body === "string" ? issue.body.slice(0, 8000) : "",
    repository_url:
      typeof issue.repository_url === "string"
        ? issue.repository_url.slice(0, 500)
        : "",
    repository:
      typeof issue.repository === "string"
        ? issue.repository.slice(0, 500)
        : "",
    html_url:
      typeof issue.html_url === "string"
        ? issue.html_url.slice(0, 500)
        : "",
    number: issue.number,
    labels: Array.isArray(issue.labels) ? issue.labels.slice(0, 30) : [],
  };
}

function handleError(res, error) {
  console.error("API error:", error.message);
  return res.status(error.status || 502).json({
    success: false,
    error: error.message || "Request failed.",
  });
}

// Register/update user profile.
app.post("/api/users", async (req, res) => {
  try {
    if (!db) {
      return res.status(503).json({ error: "Database unavailable." });
    }

    const name =
      typeof req.body.name === "string" ? req.body.name.trim() : "";
    const email =
      typeof req.body.email === "string"
        ? req.body.email.trim().toLowerCase()
        : "";
    const skills = Array.isArray(req.body.skills)
      ? [...new Set(
          req.body.skills
            .filter((skill) => typeof skill === "string")
            .map((skill) => skill.trim())
            .filter(Boolean)
        )].slice(0, 100)
      : [];

    if (!name || name.length > 100) {
      return res.status(400).json({ error: "A valid name is required." });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
      return res.status(400).json({ error: "A valid email is required." });
    }

    const now = new Date();
    const user = await db.collection("users").findOneAndUpdate(
      { email },
      {
        $set: { name, skills, updatedAt: now },
        $setOnInsert: { email, createdAt: now },
      },
      { upsert: true, returnDocument: "after", includeResultMetadata: false }
    );

    return res.json({
      success: true,
      message: "Profile and skills saved successfully.",
      profile: user
        ? { name: user.name, email: user.email, skills: user.skills }
        : null,
    });
  } catch (error) {
    return handleError(res, error);
  }
});

app.get("/api/users/:email", async (req, res) => {
  try {
    if (!db) {
      return res.status(503).json({ error: "Database unavailable." });
    }

    const email = req.params.email.trim().toLowerCase();
    const user = await db.collection("users").findOne(
      { email },
      { projection: { _id: 0, name: 1, email: 1, skills: 1 } }
    );

    if (!user) {
      return res.status(404).json({ error: "Profile not found." });
    }

    return res.json({ success: true, profile: user });
  } catch (error) {
    return handleError(res, error);
  }
});

app.post("/api/test-data", async (req, res) => {
  try {
    if (!db) {
      return res.status(503).json({ error: "Database unavailable." });
    }

    const result = await db.collection("test_data").insertOne({
      message:
        typeof req.body.message === "string"
          ? req.body.message.slice(0, 1000)
          : "MongoDB test successful",
      createdAt: new Date(),
    });

    return res.status(201).json({
      success: true,
      message: "Data saved to MongoDB",
      id: result.insertedId,
    });
  } catch (error) {
    return handleError(res, error);
  }
});

// Existing AI Issue Analyzer.
app.post("/api/ai/analyze-issue", async (req, res) => {
  try {
    const issue = safeIssue(req.body?.issue);
    const language = req.body?.language || "English";

    if (!validLanguage(language)) {
      return res.status(400).json({
        error: "Language must be English or Hindi + English.",
      });
    }

    const analysis = await analyzeIssue(issue, language);
    return res.json({ success: true, analysis });
  } catch (error) {
    return handleError(res, error);
  }
});

// Feature 1: AI Code Fix suggestion.
app.post("/api/ai/code-fix", async (req, res) => {
  try {
    const issue = safeIssue(req.body?.issue);
    const { sourceCode, filePath = "", language = "English" } = req.body;

    if (!validLanguage(language)) {
      return res.status(400).json({ error: "Invalid language." });
    }

    if (typeof sourceCode !== "string" || !sourceCode.trim()) {
      return res.status(400).json({
        error: "Paste the relevant source code first.",
      });
    }

    const fix = await generateCodeFix({
      issue,
      sourceCode,
      filePath,
      language,
    });

    return res.json({
      success: true,
      fix,
      execution: "suggestion_only",
      message: "AI suggested a fix; no files were modified.",
    });
  } catch (error) {
    return handleError(res, error);
  }
});

// Feature 2: Generate a test plan.
// This endpoint does not execute arbitrary code or shell commands.
app.post("/api/ai/test-plan", async (req, res) => {
  try {
    const issue = safeIssue(req.body?.issue);
    const {
      sourceCode = "",
      filePath = "",
      language = "English",
    } = req.body;

    if (!validLanguage(language)) {
      return res.status(400).json({ error: "Invalid language." });
    }

    const testPlan = await generateTestPlan({
      issue,
      sourceCode,
      filePath,
      language,
    });

    return res.json({
      success: true,
      testPlan,
      execution: "not_run",
      message: "Test plan generated; tests have not been executed.",
    });
  } catch (error) {
    return handleError(res, error);
  }
});

// Feature 3: Create a GitHub Pull Request.
// Requires GITHUB_TOKEN in backend .env with repository write permission.
app.post("/api/github/create-pr", async (req, res) => {
  try {
    const token = process.env.GITHUB_TOKEN;

    if (!token) {
      return res.status(503).json({
        error: "GITHUB_TOKEN is missing from backend .env.",
      });
    }

    const {
      repository,
      title,
      body,
      head,
      base = "main",
    } = req.body || {};

    // Accept only owner/repository, never arbitrary URLs.
    if (
      typeof repository !== "string" ||
      !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository)
    ) {
      return res.status(400).json({
        error: "Repository must be in owner/repository format.",
      });
    }

    if (
      typeof title !== "string" ||
      !title.trim() ||
      title.length > 256 ||
      typeof body !== "string" ||
      body.length > 60000 ||
      typeof head !== "string" ||
      !/^[A-Za-z0-9._/-]+$/.test(head) ||
      typeof base !== "string" ||
      !/^[A-Za-z0-9._/-]+$/.test(base)
    ) {
      return res.status(400).json({
        error: "Provide a valid PR title, body, head branch and base branch.",
      });
    }

    const response = await fetch(
      `https://api.github.com/repos/${repository}/pulls`,
      {
        method: "POST",
        headers: {
          Accept: "application/vnd.github+json",
          Authorization: `Bearer ${token}`,
          "X-GitHub-Api-Version": "2022-11-28",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: title.trim(),
          body,
          head,
          base,
        }),
      }
    );

    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
      return res.status(response.status).json({
        success: false,
        error:
          result.message ||
          "GitHub could not create the pull request. Check permissions and branch names.",
      });
    }

    return res.status(201).json({
      success: true,
      message: "Pull request created.",
      pullRequest: {
        number: result.number,
        title: result.title,
        url: result.html_url,
        state: result.state,
      },
    });
  } catch (error) {
    return handleError(res, error);
  }
});

async function startServer() {
  try {
    await client.connect();
    db = client.db(process.env.MONGODB_DB_NAME || "open_source_buddy");
    await db.command({ ping: 1 });

    await db.collection("users").createIndex({ email: 1 }, { unique: true });

    console.log("MongoDB connected successfully");

    app.listen(PORT, () => {
      console.log(`Backend running at http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("Startup error:", error.message);
    process.exit(1);
  }
}

startServer();
