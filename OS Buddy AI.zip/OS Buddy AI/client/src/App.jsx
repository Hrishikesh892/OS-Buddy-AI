
import { useState } from "react";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import "./App.css";

const PROFILE_KEY = "osBuddyUserProfile";
const API_URL = "http://localhost:5000/api";

function readSavedProfile() {
  try {
    const saved = localStorage.getItem(PROFILE_KEY);

    if (!saved) return null;

    const profile = JSON.parse(saved);

    if (
      typeof profile.name === "string" &&
      typeof profile.email === "string" &&
      Array.isArray(profile.skills)
    ) {
      return profile;
    }
  } catch (error) {
    console.error("Could not load saved profile:", error);
  }

  return null;
}

function App() {
  const [userProfile, setUserProfile] = useState(readSavedProfile);
  const [isLoggedIn, setIsLoggedIn] = useState(
    () => readSavedProfile() !== null
  );
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [loginError, setLoginError] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  async function saveProfileToServer(profile) {
    const normalizedProfile = {
      name: (profile.name || "").trim(),
      email: (profile.email || "").trim().toLowerCase(),
      skills: Array.isArray(profile.skills) ? profile.skills : [],
    };

    const response = await fetch(`${API_URL}/users`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(normalizedProfile),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Profile could not be saved.");
    }

    if (!data.profile) {
      throw new Error("Server did not return the saved profile.");
    }

    return data.profile;
  }

  async function handleLogin(profile) {
    setLoginError("");
    setIsSaving(true);

    try {
      const savedProfile = await saveProfileToServer(profile);

      localStorage.setItem(
        PROFILE_KEY,
        JSON.stringify(savedProfile)
      );

      setUserProfile(savedProfile);
      setIsLoggedIn(true);
      setCurrentPage("dashboard");
    } catch (error) {
      console.error("Login/profile save failed:", error);

      setLoginError(
        error.message === "Failed to fetch"
          ? "Backend se connection nahi ho raha. Check karo ki server running hai."
          : error.message || "Profile save nahi ho payi."
      );
    } finally {
      setIsSaving(false);
    }
  }

  async function handleUpdateProfile(profile) {
    const normalizedProfile = {
      ...(userProfile || {}),
      ...profile,
      name: (profile.name ?? userProfile?.name ?? "").trim(),
      email: (
        profile.email ??
        userProfile?.email ??
        ""
      ).trim().toLowerCase(),
      skills: Array.isArray(profile.skills)
        ? profile.skills
        : userProfile?.skills || [],
    };

    // Save to MongoDB first. Update local state only after success.
    const savedProfile = await saveProfileToServer(normalizedProfile);

    localStorage.setItem(
      PROFILE_KEY,
      JSON.stringify(savedProfile)
    );

    setUserProfile(savedProfile);

    return savedProfile;
  }

  function handleLogout() {
    setIsLoggedIn(false);
    setCurrentPage("dashboard");
  }

  function handleNavigation(page) {
    setCurrentPage(page);
  }

  return (
    <div className="app">
      {isLoggedIn ? (
        <Dashboard
          userName={userProfile?.name || ""}
          userProfile={userProfile}
          userSkills={userProfile?.skills || []}
          onUpdateProfile={handleUpdateProfile}
          onLogout={handleLogout}
          currentPage={currentPage}
          onNavigate={handleNavigation}
        />
      ) : (
        <>
          {loginError && (
            <p role="alert" className="app-login-error">
              {loginError}
            </p>
          )}

          <Login
            onLogin={handleLogin}
            initialProfile={userProfile}
          />

          {isSaving && (
            <div className="app-saving-message" role="status">
              Saving profile...
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default App;
