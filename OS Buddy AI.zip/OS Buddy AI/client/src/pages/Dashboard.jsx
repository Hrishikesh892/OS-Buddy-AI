
import { useEffect, useState } from "react";
import "../styles/Dashboard.css";
import FindIssues from "./FindIssues";
import IssueAnalyzer from "./IssueAnalyzer";
import ContributionGuide from "./ContributionGuide";

const SKILL_GROUPS = [
  {
    title: "Programming Languages",
    skills: [
      "JavaScript", "TypeScript", "Python", "Java", "C", "C++", "C#",
      "Go", "Rust", "PHP", "Ruby", "Kotlin", "Swift", "Dart", "R",
      "SQL", "HTML", "CSS", "Shell",
    ],
  },
  {
    title: "Frameworks & Libraries",
    skills: [
      "React", "Next.js", "Node.js", "Express.js", "Django", "Flask",
      "FastAPI", "Spring Boot", "Angular", "Vue.js", "Tailwind CSS",
      "Bootstrap", "TensorFlow", "PyTorch",
    ],
  },
  {
    title: "Tools & Other Skills",
    skills: [
      "Git", "GitHub", "Docker", "MongoDB", "MySQL", "PostgreSQL",
      "REST APIs", "Linux", "Testing", "Data Structures",
      "Machine Learning", "AI/LLM", "Documentation", "UI/UX",
    ],
  },
];

function Dashboard({
  userName,
  userProfile,
  userSkills = [],
  onUpdateProfile,
  onLogout,
  currentPage = "dashboard",
  onNavigate = () => {},
}) {
  const firstName = userName?.trim().split(/\s+/)[0] || "Developer";

  const [selectedSkills, setSelectedSkills] = useState(
    Array.isArray(userSkills) ? userSkills : []
  );
  const [customSkill, setCustomSkill] = useState("");
  const [skillMessage, setSkillMessage] = useState("");
  const [skillError, setSkillError] = useState("");
  const [isSavingSkills, setIsSavingSkills] = useState(false);

  useEffect(() => {
    setSelectedSkills(Array.isArray(userSkills) ? userSkills : []);
  }, [userSkills]);

  const navItems = [
    { id: "dashboard", icon: "▦", label: "Dashboard" },
    { id: "issues", icon: "⌕", label: "Find Issues" },
    { id: "analyzer", icon: "✳", label: "AI Issue Analyzer" },
    { id: "guide", icon: "↗", label: "Contribution Guide" },
    { id: "update-skills", icon: "⚙", label: "Update Skills" },
  ];

  const pageTitle =
    navItems.find((item) => item.id === currentPage)?.label || "Dashboard";

  function openPage(page) {
    setSkillMessage("");
    setSkillError("");
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function toggleSkill(skill) {
    setSelectedSkills((previous) =>
      previous.includes(skill)
        ? previous.filter((item) => item !== skill)
        : [...previous, skill]
    );

    setSkillMessage("");
    setSkillError("");
  }

  function addCustomSkill(event) {
    event.preventDefault();

    const skill = customSkill.trim();

    if (!skill) return;

    const exists = selectedSkills.some(
      (item) => item.toLowerCase() === skill.toLowerCase()
    );

    if (exists) {
      setSkillError("Ye skill pehle se selected hai.");
      return;
    }

    if (selectedSkills.length >= 100) {
      setSkillError("Maximum 100 skills add kar sakte ho.");
      return;
    }

    setSelectedSkills((previous) => [...previous, skill]);
    setCustomSkill("");
    setSkillMessage("");
    setSkillError("");
  }

  async function saveSkills(event) {
    event.preventDefault();
    setSkillMessage("");
    setSkillError("");

    const updatedProfile = {
      ...(userProfile || {}),
      name: userProfile?.name || userName || "",
      email: userProfile?.email || "",
      skills: [
        ...new Set(
          selectedSkills
            .filter((skill) => typeof skill === "string")
            .map((skill) => skill.trim())
            .filter(Boolean)
        ),
      ].slice(0, 100),
    };

    if (!updatedProfile.email) {
      setSkillError("Profile email nahi mili. Dobara login karo.");
      return;
    }

    setIsSavingSkills(true);

    try {
      if (typeof onUpdateProfile !== "function") {
        throw new Error("Profile save service available nahi hai.");
      }

      await onUpdateProfile(updatedProfile);

      setSkillMessage("Skills updated successfully!");
      setSkillError("");
    } catch (error) {
      console.error("Could not update skills:", error);

      setSkillError(
        error.message === "Failed to fetch"
          ? "Backend se connection nahi ho raha. Server check karo."
          : error.message || "Skills save nahi ho paayi. Dobara try karo."
      );
    } finally {
      setIsSavingSkills(false);
    }
  }

  return (
    <main className="dashboard-page">
      <aside className="dashboard-sidebar">
        <button
          className="dashboard-brand"
          onClick={() => openPage("dashboard")}
        >
          <span className="dashboard-logo">OS</span>
          <span className="dashboard-brand-text">
            OpenSource
            <strong>Buddy AI</strong>
          </span>
        </button>

        <div className="sidebar-section-label">WORKSPACE</div>

        <nav className="dashboard-nav">
          {navItems.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${
                currentPage === item.id ? "active" : ""
              }`}
              onClick={() => openPage(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              {item.label}
              {currentPage === item.id && (
                <span className="nav-indicator" />
              )}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-logout-area">
            <button className="sidebar-logout" onClick={onLogout}>
              <span>↪</span>
              Log out
            </button>
          </div>

          <div className="sidebar-version">
            <span className="version-dot" />
            OpenSource Buddy AI
            <span className="version-number">v1.0</span>
          </div>
        </div>
      </aside>

      <section className="dashboard-main">
        <header className="dashboard-header">
          <div className="dashboard-breadcrumb">
            Workspace <span>/</span> {pageTitle}
          </div>

          <div className="dashboard-header-right">
            <span className="dashboard-ai-status">
              <span className="dashboard-status-dot" />
              AI Workspace
            </span>

            <div className="dashboard-user">
              <div className="dashboard-user-avatar">
                {firstName.charAt(0).toUpperCase()}
              </div>

              <div className="dashboard-user-info">
                <strong>{firstName}</strong>
                <span>Developer</span>
              </div>
            </div>
          </div>
        </header>

        <div className="dashboard-content">
          {currentPage === "dashboard" && (
            <>
              <div className="dashboard-welcome-row">
                <div>
                  <p className="dashboard-label">
                    <span>✦</span> YOUR OPEN-SOURCE JOURNEY
                  </p>

                  <h1>
                    Welcome back, <span>{firstName}.</span>
                  </h1>

                  <p className="dashboard-description">
                    Great things start with a single contribution.
                    <br className="desktop-break" />
                    Discover projects, understand issues, and grow your skills.
                  </p>
                </div>

                <div className="dashboard-date-card">
                  <span className="date-card-symbol">✳</span>
                  <div>
                    <strong>Ready to build?</strong>
                    <p>Your next contribution starts here.</p>
                  </div>
                </div>
              </div>

              <section className="dashboard-hero">
                <div className="hero-content">
                  <div className="hero-tag">
                    <span>✦</span> YOUR AI DEVELOPER COMPANION
                  </div>

                  <h2>
                    From curious coder
                    <br />
                    to <span>open-source contributor.</span>
                  </h2>

                  <p>
                    Find an issue that matches your interests.
                    Learn what it means and discover how you can
                    contribute with confidence.
                  </p>

                  <button
                    className="hero-button"
                    onClick={() => openPage("issues")}
                  >
                    Explore your workspace <span>→</span>
                  </button>
                </div>

                <div className="hero-visual" aria-hidden="true">
                  <div className="hero-orbit orbit-one" />
                  <div className="hero-orbit orbit-two" />

                  <div className="hero-core">
                    <span>OS</span>
                    <i>✦</i>
                  </div>

                  <span className="hero-node node-one">{"{ }"}</span>
                  <span className="hero-node node-two">AI</span>
                  <span className="hero-node node-three">↗</span>
                </div>
              </section>

              <div className="dashboard-section-heading">
                <div>
                  <p className="section-eyebrow">YOUR TOOLKIT</p>
                  <h2>What would you like to do?</h2>
                </div>

                <span className="section-count">03 TOOLS</span>
              </div>

              <div className="dashboard-grid">
                <article className="dashboard-card issue-card">
                  <div className="feature-card-top">
                    <span className="card-icon issue-icon">⌕</span>
                    <span className="feature-card-number">01</span>
                  </div>

                  <span className="feature-card-tag">DISCOVER</span>
                  <h3>Find Issues</h3>
                  <p>
                    Explore GitHub issues and discover opportunities
                    to contribute to open-source projects.
                  </p>

                  <button
                    className="feature-card-link"
                    onClick={() => openPage("issues")}
                  >
                    Explore issues <span>→</span>
                  </button>
                </article>

                <article className="dashboard-card analyze-card">
                  <div className="feature-card-top">
                    <span className="card-icon analyze-icon">✳</span>
                    <span className="feature-card-number">02</span>
                  </div>

                  <span className="feature-card-tag">UNDERSTAND</span>
                  <h3>AI Issue Analyzer</h3>
                  <p>
                    Understand an issue, its requirements,
                    and the skills you may need.
                  </p>

                  <button
                    className="feature-card-link"
                    onClick={() => openPage("analyzer")}
                  >
                    Analyze an issue <span>→</span>
                  </button>
                </article>

                <article className="dashboard-card guide-card">
                  <div className="feature-card-top">
                    <span className="card-icon guide-icon">↗</span>
                    <span className="feature-card-number">03</span>
                  </div>

                  <span className="feature-card-tag">TAKE ACTION</span>
                  <h3>Contribution Guide</h3>
                  <p>
                    Learn the contribution workflow, from understanding
                    a project to preparing a pull request.
                  </p>

                  <button
                    className="feature-card-link"
                    onClick={() => openPage("guide")}
                  >
                    Learn the steps <span>→</span>
                  </button>
                </article>
              </div>

              <section className="dashboard-bottom-panel">
                <div className="bottom-panel-icon">✦</div>
                <div className="bottom-panel-copy">
                  <h3>Every expert was once a beginner.</h3>
                  <p>
                    Start small, keep learning, and make your first
                    open-source contribution one step at a time.
                  </p>
                </div>
                <span className="bottom-panel-decoration">
                  OPEN SOURCE / AI
                </span>
              </section>
            </>
          )}

          {currentPage === "issues" && (
            <FindIssues onNavigate={onNavigate} />
          )}

          {currentPage === "analyzer" && (
            <IssueAnalyzer
              userSkills={userSkills}
              onNavigate={onNavigate}
            />
          )}

          {currentPage === "guide" && (
            <ContributionGuide onNavigate={onNavigate} />
          )}

          {currentPage === "update-skills" && (
            <section className="dashboard-feature-page update-skills-page">
              <p className="section-eyebrow">YOUR DEVELOPER PROFILE</p>
              <h1>
                Update <span>Skills</span>
              </h1>
              <p>
                Select the skills you know. You can add new skills or
                remove existing ones whenever you need.
              </p>

              <form className="update-skills-form" onSubmit={saveSkills}>
                <div className="update-skills-count">
                  <span>Selected skills</span>
                  <strong>{selectedSkills.length}</strong>
                </div>

                {SKILL_GROUPS.map((group) => (
                  <details className="update-skill-dropdown" key={group.title}>
                    <summary>
                      <span>{group.title}</span>
                      <span className="update-skill-count">
                        {group.skills.filter((skill) =>
                          selectedSkills.includes(skill)
                        ).length}{" "}
                        selected
                        <span className="update-skill-chevron">⌄</span>
                      </span>
                    </summary>

                    <div className="update-skill-options">
                      {group.skills.map((skill) => {
                        const isSelected = selectedSkills.includes(skill);

                        return (
                          <label
                            className={`update-skill-option ${
                              isSelected ? "selected" : ""
                            }`}
                            key={skill}
                          >
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleSkill(skill)}
                            />
                            <span>{skill}</span>
                            <span className="update-skill-check">
                              {isSelected ? "✓" : "+"}
                            </span>
                          </label>
                        );
                      })}
                    </div>
                  </details>
                ))}

                <div className="update-custom-skill">
                  <label htmlFor="custom-skill">Add another skill</label>
                  <div>
                    <input
                      id="custom-skill"
                      value={customSkill}
                      onChange={(event) => setCustomSkill(event.target.value)}
                      placeholder="Enter a skill name"
                      maxLength={60}
                    />
                    <button type="button" onClick={addCustomSkill}>
                      Add skill
                    </button>
                  </div>
                </div>

                {selectedSkills.length > 0 && (
                  <div className="update-selected-skills">
                    <h3>Your selected skills</h3>
                    <div>
                      {selectedSkills.map((skill) => (
                        <span className="update-selected-chip" key={skill}>
                          {skill}
                          <button
                            type="button"
                            aria-label={`Remove ${skill}`}
                            onClick={() => toggleSkill(skill)}
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {skillError && (
                  <p className="update-skill-error" role="alert">
                    {skillError}
                  </p>
                )}

                {skillMessage && (
                  <p className="update-skill-success" role="status">
                    ✓ {skillMessage}
                  </p>
                )}

                <div className="update-skills-actions">
                  <button
                    type="button"
                    className="update-skills-cancel"
                    onClick={() => openPage("dashboard")}
                    disabled={isSavingSkills}
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="update-skills-save"
                    disabled={isSavingSkills}
                  >
                    {isSavingSkills ? "Saving..." : "Save Skills"}
                    {!isSavingSkills && <span> →</span>}
                  </button>
                </div>
              </form>
            </section>
          )}

          <footer className="dashboard-footer">
            <span>© 2026 OpenSource Buddy AI</span>
            <span>BUILT BY TEAM CHANKY ✦</span>
            <span>LEARN. BUILD. CONTRIBUTE.</span>
          </footer>
        </div>
      </section>
    </main>
  );
}

export default Dashboard;
