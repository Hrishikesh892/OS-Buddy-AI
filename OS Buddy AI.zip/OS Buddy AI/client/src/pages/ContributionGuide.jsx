
import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import "../styles/ContributionGuide.css";

const steps = [
  {
    title: "1. Understand the Selected Issue",
    description: "Read the issue description, expected behaviour, labels, and maintainer comments.",
    details: [
      "Identify what is broken or missing.",
      "Check the expected result and reproduction steps.",
      "Confirm that the issue is still open and suitable to work on.",
    ],
  },
  {
    title: "2. Fork the Repository",
    description: "Create your own copy of the original repository on GitHub.",
    details: [
      "Open the original repository using the link above.",
      "Click Fork and select your account.",
      "Use your fork to publish your changes.",
    ],
  },
  {
    title: "3. Clone Your Fork",
    description: "Download your forked repository to your computer.",
    command: "git clone <your-fork-url>\ncd <repository-folder>",
    details: [
      "Copy the HTTPS URL from your fork.",
      "Open a terminal in the folder where you want the project.",
    ],
  },
  {
    title: "4. Set Up the Project",
    description: "Read the README and follow the project's setup instructions.",
    command: "git status",
    details: [
      "Install the required dependencies.",
      "Run the project or existing tests.",
      "Locate the relevant code before making changes.",
    ],
  },
  {
    title: "5. Create a Branch",
    description: "Create a separate branch for this issue.",
    command: "git switch -c fix/issue-name",
    details: [
      "Choose a short, meaningful branch name.",
      "Keep your changes separate from the main branch.",
    ],
  },
  {
    title: "6. Fix and Test the Issue",
    description: "Investigate the relevant code, implement the fix, and test it.",
    details: [
      "Use the issue description and AI suggestions as guidance.",
      "Inspect the repository source code to verify the cause.",
      "Run the appropriate tests and review your changes.",
    ],
  },
  {
    title: "7. Commit Your Changes",
    description: "Save your changes with a clear commit message.",
    command: 'git add <file-name>\ngit commit -m "Fix issue description"',
    details: [
      "Review the files before staging them.",
      "Use a message that describes your actual fix.",
    ],
  },
  {
    title: "8. Push Your Branch",
    description: "Upload your branch to your GitHub fork.",
    command: "git push -u origin fix/issue-name",
    details: [
      "Use the branch name you created earlier.",
      "Check that the push completes successfully.",
    ],
  },
  {
    title: "9. Create a Pull Request",
    description: "Submit your changes to the original repository for review.",
    details: [
      "Open your fork on GitHub.",
      "Click Compare & pull request.",
      "Describe the issue, your fix, and tests performed.",
      "Link the original issue when appropriate.",
    ],
  },
  {
    title: "10. Respond to Review",
    description: "Address feedback from the project maintainers.",
    details: [
      "Read review comments carefully.",
      "Make requested changes on the same branch.",
      "Commit and push your updates.",
    ],
  },
];

function readSessionValue(key) {
  try {
    const value = sessionStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch {
    return null;
  }
}

function getRepositoryName(issue) {
  if (!issue) return "";

  if (typeof issue.repository === "string") {
    return issue.repository;
  }

  if (issue.repository?.full_name) {
    return issue.repository.full_name;
  }

  if (issue.repository_url) {
    return issue.repository_url.replace(
      "https://api.github.com/repos/",
      ""
    );
  }

  if (issue.html_url) {
    const match = issue.html_url.match(
      /^https:\/\/github\.com\/([^/]+\/[^/]+)\/issues\/\d+/
    );

    if (match) return match[1];
  }

  return "";
}

function getAnalysisSections(savedAnalysis) {
  if (!savedAnalysis) return [];

  const data = savedAnalysis.analysis ?? savedAnalysis;

  if (typeof data === "string") {
    return [{ title: "AI Analysis", content: data }];
  }

  if (typeof data !== "object" || data === null) {
    return [];
  }

  const sections = [
    {
      title: "Issue Summary",
      content:
        data.summary ??
        data.issue_summary ??
        data.problem_summary,
    },
    {
      title: "Solution Approach",
      content:
        data.solution_approach ??
        data.solutionApproach ??
        data.approach ??
        data.solution,
    },
    {
      title: "Steps to Follow",
      content:
        data.steps ??
        data.solution_steps ??
        data.implementation_steps,
    },
    {
      title: "Files to Investigate",
      content:
        data.files_to_investigate ??
        data.filesToInvestigate ??
        data.relevant_files ??
        data.files,
    },
    {
      title: "Testing Guidance",
      content:
        data.testing ??
        data.testing_guidance ??
        data.test_steps,
    },
    {
      title: "Required Skills",
      content:
        data.required_skills ??
        data.requiredSkills ??
        data.skills,
    },
    {
      title: "Difficulty",
      content: data.difficulty,
    },
    {
      title: "Learning Resources",
      content:
        data.learning_resources ??
        data.learning,
    },
  ];

  return sections.filter(
    (section) =>
      section.content !== undefined &&
      section.content !== null &&
      section.content !== ""
  );
}

function formatContent(content) {
  if (typeof content === "string") return content;

  if (Array.isArray(content)) {
    return content
      .map((item) => {
        if (typeof item === "string") return `- ${item}`;

        if (item && typeof item === "object") {
          return `- ${
            item.name ??
            item.path ??
            item.title ??
            JSON.stringify(item)
          }`;
        }

        return `- ${String(item)}`;
      })
      .join("\n");
  }

  if (typeof content === "object" && content !== null) {
    return Object.entries(content)
      .map(([key, value]) => `**${key}:** ${String(value)}`)
      .join("\n\n");
  }

  return String(content);
}

function ContributionGuide({ onNavigate }) {
  const [issue] = useState(() =>
    readSessionValue("selectedGitHubIssue")
  );

  const [savedAnalysis] = useState(() =>
    readSessionValue("selectedIssueAnalysis")
  );

  const [completed, setCompleted] = useState([]);
  const [expanded, setExpanded] = useState([0]);
  const [copyMessage, setCopyMessage] = useState("");
  const [actualContributionStarted, setActualContributionStarted] =
    useState(false);

  const progress = Math.round(
    (completed.length / steps.length) * 100
  );

  const allStepsCompleted = completed.length === steps.length;
  const repositoryName = getRepositoryName(issue);
  const analysisSections = getAnalysisSections(savedAnalysis);

  const toggleStep = (index) => {
    setCompleted((previous) =>
      previous.includes(index)
        ? previous.filter((item) => item !== index)
        : [...previous, index]
    );
  };

  const toggleExpanded = (index) => {
    setExpanded((previous) =>
      previous.includes(index)
        ? previous.filter((item) => item !== index)
        : [...previous, index]
    );
  };

  const copyCommand = async (command) => {
    try {
      await navigator.clipboard.writeText(command);
      setCopyMessage("Commands copied successfully!");
    } catch {
      setCopyMessage(
        "Copy failed. Please select and copy the commands manually."
      );
    }

    window.setTimeout(() => setCopyMessage(""), 2500);
  };

  const resetProgress = () => {
    setCompleted([]);
    setExpanded([0]);
    setActualContributionStarted(false);
  };

  const startActualContribution = () => {
    setActualContributionStarted(true);
    setExpanded([1, 2, 3, 4, 5]);
  };

  return (
    <div className="contribution-guide">
      <div className="guide-header">
        <div>
          <span className="guide-eyebrow">
            OPEN SOURCE FOR BEGINNERS
          </span>

          <h1>Contribution Guide</h1>

          <p>
            Follow the steps to work on a GitHub issue and submit
            your contribution.
          </p>
        </div>

        <a
          href="https://docs.github.com/en/get-started/exploring-projects-on-github/contributing-to-a-project"
          target="_blank"
          rel="noopener noreferrer"
          className="guide-docs-link"
        >
          GitHub Documentation ↗
        </a>
      </div>

      <section className="guide-progress-card">
        <div className="guide-progress-top">
          <span>Your Contribution Progress</span>
          <strong>{progress}%</strong>
        </div>

        <div
          className="guide-progress-track"
          role="progressbar"
          aria-label="Contribution progress"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={progress}
        >
          <div
            className="guide-progress-fill"
            style={{ width: `${progress}%` }}
          />
        </div>

        <p>
          {completed.length} of {steps.length} steps completed
        </p>

        <div className="guide-progress-actions">
          <span>
            {allStepsCompleted
              ? "All guide steps completed!"
              : "Mark each step when you finish it."}
          </span>

          <button type="button" onClick={resetProgress}>
            Reset Progress
          </button>
        </div>
      </section>

      {allStepsCompleted && (
        <section className="guide-completion-card">
          <h2>🎉 Contribution Guide Completed!</h2>

          <p>
            You have marked all 10 guide steps complete.
            Now verify your work and continue with the actual
            repository contribution.
          </p>

          {!actualContributionStarted ? (
            <button
              type="button"
              onClick={startActualContribution}
              className="guide-footer-button"
            >
              Continue to Actual Contribution →
            </button>
          ) : (
            <div className="guide-actual-next-step">
              <h3>Next: Work on the Selected Issue</h3>

              <ol>
                <li>Open the original issue and repository.</li>
                <li>Fork the repository into your GitHub account.</li>
                <li>Clone your fork onto your computer.</li>
                <li>Set up the project and inspect its source code.</li>
                <li>Implement the fix and run the appropriate tests.</li>
                <li>Commit and push your changes, then create a Pull Request.</li>
              </ol>

              {issue?.html_url && (
                <p>
                  <a
                    href={issue.html_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="guide-docs-link"
                  >
                    Open Selected Issue on GitHub ↗
                  </a>
                </p>
              )}

              {repositoryName && (
                <p>
                  <a
                    href={`https://github.com/${repositoryName}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="guide-docs-link"
                  >
                    Open Repository ↗
                  </a>
                </p>
              )}

              <p>
                AI suggestions are guidance, not verified fixes.
                Inspect the repository code and run tests before
                submitting your contribution.
              </p>

              <button
                type="button"
                className="guide-footer-button"
                onClick={() => onNavigate?.("analyzer")}
                disabled={!issue}
              >
                Return to AI Issue Analyzer →
              </button>
            </div>
          )}
        </section>
      )}

      <section className="guide-selected-issue">
        <h3>Selected GitHub Issue</h3>

        {issue ? (
          <>
            <h2 className="guide-issue-title">
              {issue.title || "Untitled issue"}
              {issue.number != null && ` #${issue.number}`}
            </h2>

            {repositoryName && (
              <p className="guide-repository">
                Repository: {repositoryName}
              </p>
            )}

            <p className="guide-issue-description">
              {issue.body?.trim()
                ? issue.body.slice(0, 1200) +
                  (issue.body.length > 1200 ? "..." : "")
                : "No issue description is available. Open the issue on GitHub to read its details."}
            </p>

            {issue.html_url && (
              <a
                href={issue.html_url}
                target="_blank"
                rel="noopener noreferrer"
                className="guide-docs-link"
              >
                Open Original Issue ↗
              </a>
            )}
          </>
        ) : (
          <>
            <p className="guide-issue-description">
              No issue is selected yet. Go to Find Issues, select an
              issue, and use Analyze This Issue first.
            </p>

            <button
              type="button"
              onClick={() => onNavigate?.("issues")}
              className="guide-footer-button"
            >
              Find Issues →
            </button>
          </>
        )}
      </section>

      <section className="guide-ai-analysis">
        {analysisSections.length > 0 ? (
          <div className="guide-ai-sections">
            {analysisSections.map((section) => (
              <article
                className="guide-ai-section"
                key={section.title}
              >
                <h3>{section.title}</h3>

                <div className="guide-ai-content">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {formatContent(section.content)}
                  </ReactMarkdown>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="guide-ai-empty">
            <p>
              AI analysis is not available yet. Analyze the selected
              issue first, then return to this guide.
            </p>

            <button
              type="button"
              onClick={() => onNavigate?.("analyzer")}
              className="guide-footer-button"
              disabled={!issue}
            >
              Open AI Issue Analyzer →
            </button>
          </div>
        )}
      </section>

      {copyMessage && (
        <div className="guide-copy-status" role="status">
          {copyMessage}
        </div>
      )}

      <div className="guide-steps">
        {steps.map((step, index) => (
          <section
            className={`guide-step ${
              completed.includes(index) ? "completed" : ""
            }`}
            key={step.title}
          >
            <div className="guide-step-heading">
              <label className="guide-checkbox">
                <input
                  type="checkbox"
                  checked={completed.includes(index)}
                  onChange={() => toggleStep(index)}
                />

                <span>{step.title}</span>
              </label>

              <button
                type="button"
                className="guide-expand-button"
                onClick={() => toggleExpanded(index)}
                aria-expanded={expanded.includes(index)}
              >
                {expanded.includes(index)
                  ? "Hide details −"
                  : "View details +"}
              </button>
            </div>

            <p>{step.description}</p>

            {expanded.includes(index) && (
              <div className="guide-step-details">
                <h4>What to do</h4>

                <ul>
                  {step.details.map((detail) => (
                    <li key={detail}>{detail}</li>
                  ))}
                </ul>

                {step.command && (
                  <div className="guide-command">
                    <pre>
                      <code>{step.command}</code>
                    </pre>

                    <button
                      type="button"
                      onClick={() => copyCommand(step.command)}
                    >
                      Copy Commands
                    </button>
                  </div>
                )}
              </div>
            )}
          </section>
        ))}
      </div>

      <div className="guide-footer">
        <h3>Ready to continue?</h3>

        <p>
          Review the selected issue, follow the contribution steps,
          test your changes, and submit your Pull Request.
        </p>

        <button
          type="button"
          onClick={() => onNavigate?.("issues")}
        >
          Back to Find Issues →
        </button>
      </div>
    </div>
  );
}

export default ContributionGuide;
