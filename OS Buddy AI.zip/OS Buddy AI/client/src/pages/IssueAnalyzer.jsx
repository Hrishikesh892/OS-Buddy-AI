
import { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import "../styles/IssueAnalyzer.css";

const API_URL = "http://localhost:5000";

function getRepositoryName(repositoryUrl = "", repository = "") {
  if (repository && typeof repository === "object" && repository.full_name) {
    return repository.full_name;
  }

  if (typeof repository === "string" && repository.includes("/")) {
    return repository;
  }

  return String(repositoryUrl || "")
    .replace(/\/+$/, "")
    .replace("https://api.github.com/repos/", "")
    .replace("https://github.com/", "")
    .split("/")
    .slice(-2)
    .join("/");
}

function normalizeSkills(skills) {
  return (Array.isArray(skills) ? skills : [])
    .map((skill) => String(skill).trim().toLowerCase())
    .filter(Boolean);
}

function getIssueLabels(issue) {
  return (Array.isArray(issue?.labels) ? issue.labels : [])
    .map((label) =>
      typeof label === "string" ? label : label?.name || ""
    )
    .filter(Boolean);
}

function MarkdownContent({ children }) {
  return (
    <div className="ai-analysis-text">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ node, ...props }) => (
            <a {...props} target="_blank" rel="noopener noreferrer" />
          ),
        }}
      >
        {children || ""}
      </ReactMarkdown>
    </div>
  );
}

async function postJSON(path, body) {
  const response = await fetch(`${API_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || `Request failed (${response.status}).`);
  }

  return data;
}

export default function IssueAnalyzer({
  userSkills = [],
  onNavigate = () => {},
}) {
  const [selectedIssue, setSelectedIssue] = useState(null);
  const [solutionLanguage, setSolutionLanguage] = useState("English");

  const [analysis, setAnalysis] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [requestId, setRequestId] = useState(0);

  // Code Fix and Testing
  const [sourceCode, setSourceCode] = useState("");
  const [filePath, setFilePath] = useState("");
  const [codeFix, setCodeFix] = useState("");
  const [testPlan, setTestPlan] = useState("");
  const [fixLoading, setFixLoading] = useState(false);
  const [testLoading, setTestLoading] = useState(false);
  const [workflowError, setWorkflowError] = useState("");
  const [testStatus, setTestStatus] = useState("not_run");
  const [testResults, setTestResults] = useState("");

  // Pull Request
  const [prRepository, setPrRepository] = useState("");
  const [prTitle, setPrTitle] = useState("");
  const [prBody, setPrBody] = useState("");
  const [headBranch, setHeadBranch] = useState("");
  const [baseBranch, setBaseBranch] = useState("main");
  const [prLoading, setPrLoading] = useState(false);
  const [prError, setPrError] = useState("");
  const [prResult, setPrResult] = useState(null);

  useEffect(() => {
    function loadIssue() {
      try {
        const saved = sessionStorage.getItem("selectedGitHubIssue");
        const issue = saved ? JSON.parse(saved) : null;

        setSelectedIssue(issue);
        setAnalysis("");
        setError("");
        setCodeFix("");
        setTestPlan("");
        setWorkflowError("");
        setTestStatus("not_run");
        setTestResults("");
        setPrError("");
        setPrResult(null);

        const repo = getRepositoryName(
          issue?.repository_url,
          issue?.repository
        );

        setPrRepository(repo);
        setPrTitle(
          issue?.title ? `Fix: ${issue.title}`.slice(0, 256) : ""
        );
        setPrBody(
          issue?.html_url
            ? `## Summary\n\nProposed fix for #${issue.number ?? ""}.\n\n## Related Issue\n${issue.html_url}\n\n## Testing\n\n- [ ] Tests run successfully\n- [ ] Changes reviewed`
            : "## Summary\n\n## Changes\n\n## Testing\n\n- [ ] Tests run successfully\n- [ ] Changes reviewed"
        );
      } catch (err) {
        console.error("Could not load selected issue:", err);
        setSelectedIssue(null);
      }
    }

    loadIssue();
    window.addEventListener("focus", loadIssue);
    return () => window.removeEventListener("focus", loadIssue);
  }, []);

  useEffect(() => {
    if (!selectedIssue?.title) return;

    const controller = new AbortController();

    async function fetchAnalysis() {
      setLoading(true);
      setError("");
      setAnalysis("");

      try {
        const response = await fetch(`${API_URL}/api/ai/analyze-issue`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            issue: selectedIssue,
            language: solutionLanguage,
          }),
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok) {
          throw new Error(data.error || `Analysis failed (${response.status}).`);
        }

        if (!data.analysis) {
          throw new Error("AI returned an empty analysis.");
        }

        setAnalysis(data.analysis);
      } catch (err) {
        if (err.name === "AbortError") return;
        setError(err.message || "Could not connect to AI.");
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }

    fetchAnalysis();
    return () => controller.abort();
  }, [selectedIssue, solutionLanguage, requestId]);

  const runCodeFix = async () => {
    if (!sourceCode.trim()) {
      setWorkflowError("Pehle relevant source code paste karo.");
      return;
    }

    setFixLoading(true);
    setWorkflowError("");
    setCodeFix("");
    setPrResult(null);

    try {
      const data = await postJSON("/api/ai/code-fix", {
        issue: selectedIssue,
        sourceCode,
        filePath,
        language: solutionLanguage,
      });

      setCodeFix(data.fix || "");
      setPrBody((previous) =>
        `${previous}\n\n## AI Proposed Fix\n\n${data.fix || ""}`.slice(0, 60000)
      );
    } catch (err) {
      setWorkflowError(err.message);
    } finally {
      setFixLoading(false);
    }
  };

  const runTestPlan = async () => {
    setTestLoading(true);
    setWorkflowError("");
    setTestPlan("");

    try {
      const data = await postJSON("/api/ai/test-plan", {
        issue: selectedIssue,
        sourceCode,
        filePath,
        language: solutionLanguage,
      });

      setTestPlan(data.testPlan || "");
      setTestStatus("not_run");
      setTestResults(
        "Test plan generated. No test command has been executed by this feature."
      );
    } catch (err) {
      setWorkflowError(err.message);
    } finally {
      setTestLoading(false);
    }
  };

  const createPullRequest = async (event) => {
    event.preventDefault();
    setPrLoading(true);
    setPrError("");
    setPrResult(null);

    try {
      const data = await postJSON("/api/github/create-pr", {
        repository: prRepository.trim(),
        title: prTitle.trim(),
        body: prBody,
        head: headBranch.trim(),
        base: baseBranch.trim(),
      });

      setPrResult(data.pullRequest);
    } catch (err) {
      setPrError(err.message);
    } finally {
      setPrLoading(false);
    }
  };

  const openContributionGuide = () => {
    sessionStorage.setItem(
      "selectedGitHubIssue",
      JSON.stringify(selectedIssue)
    );

    sessionStorage.setItem(
      "selectedIssueAnalysis",
      JSON.stringify({
        analysis,
        language: solutionLanguage,
        repositoryName: getRepositoryName(
          selectedIssue.repository_url,
          selectedIssue.repository
        ),
        savedAt: Date.now(),
      })
    );

    onNavigate("guide");
  };

  if (!selectedIssue) {
    return (
      <section className="dashboard-feature-page">
        <p className="section-eyebrow">UNDERSTAND THE TASK</p>
        <h1>AI Issue <span>Analyzer</span></h1>
        <div className="feature-coming-card">
          <h2>No issue selected</h2>
          <p>Go to Find Issues and select an issue first.</p>
          <button
            className="feature-card-link"
            type="button"
            onClick={() => onNavigate("issues")}
          >
            Browse Issues →
          </button>
        </div>
      </section>
    );
  }

  const labels = getIssueLabels(selectedIssue);
  const normalizedUserSkills = normalizeSkills(userSkills);

  const skillNames = [
    "JavaScript", "TypeScript", "React", "Python", "HTML", "CSS",
    "Git", "GitHub", "Testing", "Documentation", "REST APIs", "SQL",
    "Docker", "Debugging", "Accessibility", "Security", "Node.js",
    "MongoDB", "Express.js", "Java", "C++", "C", "Problem Solving",
  ];

  const detectedSkills = skillNames.filter((skill) => {
    const escaped = skill.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(
      `(^|[^a-zA-Z0-9+#.])${escaped}([^a-zA-Z0-9+#.]|$)`,
      "i"
    ).test(analysis);
  });

  const matchedSkills = detectedSkills.filter((skill) =>
    normalizedUserSkills.includes(skill.toLowerCase())
  );

  const missingSkills = detectedSkills.filter(
    (skill) => !normalizedUserSkills.includes(skill.toLowerCase())
  );

  return (
    <section className="dashboard-feature-page">
      <p className="section-eyebrow">UNDERSTAND THE TASK</p>
      <h1>AI Issue <span>Analyzer</span></h1>
      <p>Understand, plan, fix and prepare your open-source contribution.</p>

      <div className="feature-coming-card">
        <h2>{selectedIssue.title || "Untitled issue"}</h2>
        <p>
          <strong>Repository:</strong>{" "}
          {getRepositoryName(
            selectedIssue.repository_url,
            selectedIssue.repository
          ) || "Not available"}
        </p>
        <p><strong>Issue number:</strong> #{selectedIssue.number ?? "N/A"}</p>
        <p><strong>Status:</strong> {selectedIssue.state || "Unknown"}</p>

        <div className="github-issue-labels">
          {labels.map((label, index) => (
            <span className="github-label" key={`${label}-${index}`}>
              {label}
            </span>
          ))}
        </div>

        <h3>Problem Overview</h3>
        <p>{selectedIssue.body?.trim() || "No description provided."}</p>

        {selectedIssue.html_url && (
          <a
            className="github-issue-link"
            href={selectedIssue.html_url}
            target="_blank"
            rel="noopener noreferrer"
          >
            View Original GitHub Issue ↗
          </a>
        )}
      </div>

      <div className="feature-coming-card solution-approach-card">
        <div className="solution-approach-header">
          <h2>AI Issue Analysis</h2>
          <label className="solution-language-control">
            <span>ANALYSIS LANGUAGE</span>
            <select
              value={solutionLanguage}
              onChange={(event) => setSolutionLanguage(event.target.value)}
              disabled={loading || fixLoading || testLoading}
            >
              <option value="English">English</option>
              <option value="Hindi + English">Hindi + English</option>
            </select>
          </label>
        </div>

        {loading && <p role="status">AI is analyzing the issue...</p>}
        {error && <p role="alert">{error}</p>}

        {analysis && !loading && (
          <>
            <div className="ai-analysis-result">
              <MarkdownContent>{analysis}</MarkdownContent>
            </div>

            <h3>Skills Matched With Your Profile</h3>
            <div className="github-issue-labels">
              {matchedSkills.length ? matchedSkills.map((skill) => (
                <span className="github-label" key={skill}>✓ {skill}</span>
              )) : <p>No matching skills detected.</p>}
            </div>

            <h3>Skills You May Need to Learn</h3>
            <div className="github-issue-labels">
              {missingSkills.length ? missingSkills.map((skill) => (
                <span className="github-label" key={skill}>{skill}</span>
              )) : <p>No additional skills detected.</p>}
            </div>

            <button
              className="feature-card-link"
              type="button"
              onClick={() => onNavigate("update-skills")}
            >
              Update My Skills →
            </button>
            <button
              className="feature-card-link"
              type="button"
              onClick={() => setRequestId((value) => value + 1)}
            >
              Analyze Again ↻
            </button>
          </>
        )}
      </div>

      {/* FEATURE 1: AI CODE FIX */}
      <div className="feature-coming-card workflow-card">
        <h2>1. AI Code Fix</h2>
        <p>
          Paste the relevant file or code section. AI will suggest a fix;
          it will not edit your local files automatically.
        </p>

        <label className="workflow-field">
          File path (optional)
          <input
            value={filePath}
            onChange={(event) => setFilePath(event.target.value)}
            placeholder="src/example.js"
          />
        </label>

        <label className="workflow-field">
          Source code
          <textarea
            value={sourceCode}
            onChange={(event) => setSourceCode(event.target.value)}
            placeholder="Paste relevant source code here..."
            rows={10}
          />
        </label>

        <button
          className="feature-card-link"
          type="button"
          onClick={runCodeFix}
          disabled={fixLoading || !sourceCode.trim()}
        >
          {fixLoading ? "Generating Fix..." : "Generate Code Fix"}
        </button>

        {codeFix && (
          <div className="ai-analysis-result">
            <h3>AI Proposed Fix</h3>
            <MarkdownContent>{codeFix}</MarkdownContent>
            <button
              type="button"
              className="feature-card-link"
              onClick={() => {
                setSourceCode(codeFix);
                setTestResults(
                  "AI output copied into the source editor. Review it before using it."
                );
              }}
            >
              Use AI Output in Editor
            </button>
          </div>
        )}
      </div>

      {/* FEATURE 2: TEST PLAN AND RESULTS */}
      <div className="feature-coming-card workflow-card">
        <h2>2. Code Testing</h2>
        <p>
          Generate a project-specific test plan. This button does not
          execute commands on your computer.
        </p>

        <button
          className="feature-card-link"
          type="button"
          onClick={runTestPlan}
          disabled={testLoading}
        >
          {testLoading ? "Preparing Test Plan..." : "Generate Test Plan"}
        </button>

        {testPlan && (
          <div className="ai-analysis-result">
            <h3>Suggested Test Plan</h3>
            <MarkdownContent>{testPlan}</MarkdownContent>
          </div>
        )}

        <h3>Actual Test Results</h3>
        <p>
          Current status: <strong>
            {testStatus === "not_run" ? "Not run" : testStatus}
          </strong>
        </p>
        <p>{testResults || "No actual test results recorded."}</p>
        <label className="workflow-field">
          Record test results after running tests yourself
          <textarea
            rows={3}
            value={testResults}
            onChange={(event) => setTestResults(event.target.value)}
            placeholder="Paste the actual command output or test summary..."
          />
        </label>
        <label className="workflow-field">
          Test status
          <select
            value={testStatus}
            onChange={(event) => setTestStatus(event.target.value)}
          >
            <option value="not_run">Not run</option>
            <option value="passed">Passed (verified by me)</option>
            <option value="failed">Failed</option>
            <option value="blocked">Blocked</option>
          </select>
        </label>
        <p>
          Only mark tests as passed after you have actually run them and
          checked the output.
        </p>
      </div>

      {workflowError && (
        <div className="feature-coming-card" role="alert">
          <h3>Workflow Error</h3>
          <p>{workflowError}</p>
        </div>
      )}

      {/* FEATURE 3: GITHUB PULL REQUEST */}
      <div className="feature-coming-card workflow-card">
        <h2>3. GitHub Pull Request</h2>
        <p>
          Push your changes to a GitHub branch first. Then create a PR
          from that branch into the target branch.
        </p>

        <form onSubmit={createPullRequest}>
          <label className="workflow-field">
            Repository (owner/repository)
            <input
              required
              value={prRepository}
              onChange={(event) => setPrRepository(event.target.value)}
              placeholder="owner/repository"
            />
          </label>

          <label className="workflow-field">
            Source branch (head)
            <input
              required
              value={headBranch}
              onChange={(event) => setHeadBranch(event.target.value)}
              placeholder="your-fix-branch"
            />
          </label>

          <label className="workflow-field">
            Target branch (base)
            <input
              required
              value={baseBranch}
              onChange={(event) => setBaseBranch(event.target.value)}
              placeholder="main"
            />
          </label>

          <label className="workflow-field">
            PR title
            <input
              required
              maxLength={256}
              value={prTitle}
              onChange={(event) => setPrTitle(event.target.value)}
            />
          </label>

          <label className="workflow-field">
            PR description
            <textarea
              required
              rows={8}
              maxLength={60000}
              value={prBody}
              onChange={(event) => setPrBody(event.target.value)}
            />
          </label>

          <p>
            Confirm that your branch exists, changes are pushed, and the
            description is accurate before creating the PR.
          </p>

          <button
            className="feature-card-link"
            type="submit"
            disabled={prLoading}
          >
            {prLoading ? "Creating Pull Request..." : "Create GitHub Pull Request"}
          </button>
        </form>

        {prError && <p role="alert">{prError}</p>}

        {prResult && (
          <div className="ai-analysis-result" role="status">
            <h3>Pull Request Created</h3>
            <p>#{prResult.number}: {prResult.title}</p>
            <p>Status: {prResult.state}</p>
            <a
              className="github-issue-link"
              href={prResult.url}
              target="_blank"
              rel="noopener noreferrer"
            >
              Open Pull Request ↗
            </a>
          </div>
        )}
      </div>

      <div className="feature-coming-card">
        <h2>Ready to Contribute?</h2>
        <p>
          Continue to the Contribution Guide with this issue and its
          analysis saved.
        </p>
        <div className="solution-action-buttons">
          <button
            className="feature-card-link"
            type="button"
            onClick={() => onNavigate("issues")}
          >
            ← Back to Find Issues
          </button>
          <button
            className="feature-card-link"
            type="button"
            onClick={openContributionGuide}
            disabled={loading || !analysis}
          >
            Start Contributing →
          </button>
        </div>
      </div>
    </section>
  );
}
