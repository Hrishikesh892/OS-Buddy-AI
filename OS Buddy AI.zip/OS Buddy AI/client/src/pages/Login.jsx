import { useState } from "react";
import "../styles/Login.css";

const SKILL_OPTIONS = [
  {
    title: "Programming Languages",
    description: "Choose the languages you know",
    skills: [
      "JavaScript",
      "TypeScript",
      "Python",
      "Java",
      "C",
      "C++",
      "C#",
      "Go",
      "Rust",
      "PHP",
      "Ruby",
      "Kotlin",
      "Swift",
      "Dart",
      "R",
      "SQL",
      "HTML",
      "CSS",
      "Shell",
    ],
  },
  {
    title: "Frameworks & Libraries",
    description: "Select frameworks and libraries",
    skills: [
      "React",
      "Next.js",
      "Node.js",
      "Express.js",
      "Django",
      "Flask",
      "FastAPI",
      "Spring Boot",
      "Angular",
      "Vue.js",
      "Tailwind CSS",
      "Bootstrap",
      "TensorFlow",
      "PyTorch",
    ],
  },
  {
    title: "Tools & Other Skills",
    description: "Choose tools and technical skills",
    skills: [
      "Git",
      "GitHub",
      "Docker",
      "MongoDB",
      "MySQL",
      "PostgreSQL",
      "REST APIs",
      "Linux",
      "Testing",
      "Data Structures",
      "Machine Learning",
      "AI/LLM",
      "Documentation",
      "UI/UX",
    ],
  },
];

function Login({ onLogin, initialProfile }) {
  const [name, setName] = useState(initialProfile?.name || "");
  const [email, setEmail] = useState(initialProfile?.email || "");
  const [selectedSkills, setSelectedSkills] = useState(
    Array.isArray(initialProfile?.skills) ? initialProfile.skills : []
  );
  const [customSkill, setCustomSkill] = useState("");
  const [error, setError] = useState("");

  function toggleSkill(skill) {
    setSelectedSkills((currentSkills) =>
      currentSkills.includes(skill)
        ? currentSkills.filter((item) => item !== skill)
        : [...currentSkills, skill]
    );
    setError("");
  }

  function addCustomSkill(event) {
    event.preventDefault();

    const skill = customSkill.trim();

    if (!skill) return;

    const alreadyExists = selectedSkills.some(
      (item) => item.toLowerCase() === skill.toLowerCase()
    );

    if (alreadyExists) {
      setError("This skill is already selected.");
      return;
    }

    setSelectedSkills((currentSkills) => [...currentSkills, skill]);
    setCustomSkill("");
    setError("");
  }

  function handleSubmit(event) {
    event.preventDefault();

    if (!name.trim() || !email.trim()) return;

    onLogin({
      name: name.trim(),
      email: email.trim(),
      skills: selectedSkills,
    });
  }

  return (
    <main className="login-page">
      <div className="login-orb login-orb-one" />
      <div className="login-orb login-orb-two" />
      <div className="login-grid" />

      <nav className="login-navbar">
        <a className="login-brand" href="#home">
          <span className="brand-mark">
            <span>OS</span>
            <i />
          </span>

          <span className="brand-name">
            OpenSource<span>Buddy AI</span>
          </span>
        </a>

        <div className="nav-status">
          <span className="status-dot" />
          AI-powered developer platform
        </div>
      </nav>

      <section className="login-layout" id="home">
        <div className="login-intro">
          <div className="eyebrow">
            <span className="eyebrow-spark">✦</span>
            YOUR OPEN-SOURCE JOURNEY STARTS HERE
          </div>

          <h1>
            Code with purpose.
            <br />
            <span>Contribute with AI.</span>
          </h1>

          <p className="intro-description">
            Find your next GitHub contribution, understand complex
            issues, and turn your coding skills into real-world impact.
          </p>

          <div className="intro-features">
            <div className="intro-feature">
              <span className="feature-icon purple-icon">⌘</span>
              <div>
                <strong>Understand issues</strong>
                <p>Break complex problems into simple steps.</p>
              </div>
            </div>

            <div className="intro-feature">
              <span className="feature-icon blue-icon">↗</span>
              <div>
                <strong>Build real experience</strong>
                <p>Learn how open-source contributions work.</p>
              </div>
            </div>

            <div className="intro-feature">
              <span className="feature-icon pink-icon">✳</span>
              <div>
                <strong>Grow with AI</strong>
                <p>Get guidance throughout your journey.</p>
              </div>
            </div>
          </div>

          <div className="login-quote">
            <span className="quote-line" />
            <p>
              Every great developer started by contributing
              one small improvement.
            </p>
          </div>
        </div>

        <div className="login-card-wrap">
          <div className="login-card">
            <div className="card-topline">
              <span className="card-label">WELCOME ABOARD</span>
              <span className="card-sparkle">✦</span>
            </div>

            <div className="login-avatar">
              <div className="avatar-ring">
                <span className="avatar-symbol">⌘</span>
              </div>
            </div>

            <h2>Build something meaningful.</h2>
            <p className="login-subtitle">
              Your next contribution starts with you.
            </p>

            <form onSubmit={handleSubmit}>
              <div className="form-field">
                <label htmlFor="user-name">Your name</label>
                <div className="input-shell">
                  <span className="input-icon">♙</span>
                  <input
                    id="user-name"
                    type="text"
                    placeholder="How should we call you?"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    autoComplete="name"
                    required
                  />
                </div>
              </div>

              <div className="form-field">
                <label htmlFor="user-email">Email address</label>
                <div className="input-shell">
                  <span className="input-icon">✉</span>
                  <input
                    id="user-email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    autoComplete="email"
                    required
                  />
                </div>
              </div>

              <div className="profile-skills-section">
                <div className="profile-skills-heading">
                  <label>Choose your skills</label>
                  <small>{selectedSkills.length} selected</small>
                </div>

                <div className="skill-dropdown-list">
                  {SKILL_OPTIONS.map((group) => {
                    const selectedCount = group.skills.filter((skill) =>
                      selectedSkills.includes(skill)
                    ).length;

                    return (
                      <details className="skill-dropdown" key={group.title}>
                        <summary className="skill-dropdown-trigger">
                          <span className="skill-dropdown-title">
                            <strong>{group.title}</strong>
                            <small>{group.description}</small>
                          </span>

                          <span className="skill-dropdown-right">
                            <span className="skill-count-badge">
                              {selectedCount}
                            </span>
                            <span className="skill-chevron">⌄</span>
                          </span>
                        </summary>

                        <div className="skill-dropdown-panel">
                          <div className="skill-option-list">
                            {group.skills.map((skill) => {
                              const selected =
                                selectedSkills.includes(skill);

                              return (
                                <button
                                  key={skill}
                                  type="button"
                                  className={`skill-option ${
                                    selected ? "selected" : ""
                                  }`}
                                  aria-pressed={selected}
                                  onClick={() => toggleSkill(skill)}
                                >
                                  {selected ? "✓ " : "+ "}
                                  {skill}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </details>
                    );
                  })}
                </div>

                {selectedSkills.length > 0 && (
                  <div className="profile-selected-skills">
                    {selectedSkills.map((skill) => (
                      <span key={skill} title={skill}>
                        {skill}
                        <button
                          type="button"
                          aria-label={`Remove ${skill}`}
                          onClick={() => toggleSkill(skill)}
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                )}

                <div className="custom-skill-form">
                  <input
                    type="text"
                    placeholder="Add another skill..."
                    value={customSkill}
                    onChange={(event) =>
                      setCustomSkill(event.target.value)
                    }
                    aria-label="Add a custom skill"
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        event.preventDefault();
                        addCustomSkill(event);
                      }
                    }}
                  />

                  <button type="button" onClick={addCustomSkill}>
                    + Add
                  </button>
                </div>

                {error && <p className="profile-skill-error">{error}</p>}
              </div>

              <button type="submit" className="login-button">
                <span>Enter your workspace</span>
                <span className="button-arrow">→</span>
              </button>
            </form>

            <div className="login-divider">
              <span />
              <p>YOUR DEVELOPER JOURNEY</p>
              <span />
            </div>

            <div className="journey-steps">
              <span>Discover</span>
              <b>→</b>
              <span>Learn</span>
              <b>→</b>
              <span>Contribute</span>
            </div>

            <p className="login-privacy">
              <span>✦</span> A workspace built for curious developers.
            </p>
          </div>

          <div className="floating-badge badge-top">
            <span className="badge-icon">✧</span>
            <span>
              <strong>AI-guided learning</strong>
              <small>Learn at your own pace</small>
            </span>
          </div>
        </div>
      </section>

      <footer className="login-footer">
        <span>© 2026 OpenSource Buddy AI</span>
        <span className="footer-center">
          TEAM <span>CHANKY ✦</span>
        </span>
        <span className="footer-right">
          Learn <i /> Build <i /> Contribute
        </span>
      </footer>
    </main>
  );
}

export default Login;