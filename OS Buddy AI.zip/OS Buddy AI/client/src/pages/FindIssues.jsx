
import { useEffect, useState } from "react";
import "../styles/FindIssues.css";

const GITHUB_API = "https://api.github.com/search/issues";
const PAGE_SIZE = 10;

function getRepositoryName(repositoryUrl = "") {
  const parts = repositoryUrl.split("/");
  return parts.length >= 2
    ? `${parts[parts.length - 2]}/${parts[parts.length - 1]}`
    : "GitHub Repository";
}

function formatDate(dateString) {
  if (!dateString) return "Recently updated";

  const date = new Date(dateString);

  if (Number.isNaN(date.getTime())) return "Recently updated";

  return date.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function cleanDescription(body = "") {
  return body
    .replace(/https?:\/\/\S+/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function FindIssues({ onNavigate, onSolveIssue }) {
  const [keyword, setKeyword] = useState("");
  const [beginnerOnly, setBeginnerOnly] = useState(true);
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [totalCount, setTotalCount] = useState(0);
  const [page, setPage] = useState(1);
  const [retryCount, setRetryCount] = useState(0);

  const [searchSettings, setSearchSettings] = useState({
    keyword: "",
    beginnerOnly: true,
  });

  useEffect(() => {
    const controller = new AbortController();

    async function fetchIssues() {
      setLoading(true);
      setError("");

      const queryParts = ["is:issue", "is:open", "no:assignee"];
      const searchTerm = searchSettings.keyword.trim();

      if (searchTerm) {
        queryParts.push(searchTerm);
      }

      if (searchSettings.beginnerOnly) {
        queryParts.push('label:"good first issue"');
      }

      const url = new URL(GITHUB_API);
      url.searchParams.set("q", queryParts.join(" "));
      url.searchParams.set("per_page", String(PAGE_SIZE));
      url.searchParams.set("page", String(page));
      url.searchParams.set("sort", "updated");
      url.searchParams.set("order", "desc");

      try {
        const response = await fetch(url.toString(), {
          signal: controller.signal,
          headers: {
            Accept: "application/vnd.github+json",
          },
        });

        if (response.status === 403 || response.status === 429) {
          throw new Error(
            "GitHub API rate limit reach ho gaya hai. Thodi der baad try karo."
          );
        }

        if (!response.ok) {
          throw new Error(
            `GitHub se issues load nahi hue (Error ${response.status}).`
          );
        }

        const data = await response.json();

        if (!controller.signal.aborted) {
          setIssues(Array.isArray(data.items) ? data.items : []);
          setTotalCount(data.total_count || 0);
        }
      } catch (err) {
        if (err.name === "AbortError") return;

        setIssues([]);
        setTotalCount(0);
        setError(
          err.message ||
            "Issues load nahi ho paaye. Internet connection check karo."
        );
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    fetchIssues();

    return () => controller.abort();
  }, [searchSettings, page, retryCount]);

  function handleSearch(event) {
    event.preventDefault();
    setPage(1);
    setSearchSettings({
      keyword: keyword.trim(),
      beginnerOnly,
    });
  }

  function clearFilters() {
    setKeyword("");
    setBeginnerOnly(false);
    setPage(1);
    setSearchSettings({
      keyword: "",
      beginnerOnly: false,
    });
  }

  function handleSolveIssue(issue) {
    try {
      sessionStorage.setItem("selectedGitHubIssue", JSON.stringify(issue));
    } catch (err) {
      console.error("Could not save selected issue:", err);
    }

    if (onSolveIssue) {
      onSolveIssue(issue);
    } else if (onNavigate) {
      onNavigate("analyzer");
    }
  }

  const totalPages = Math.min(
    Math.ceil(totalCount / PAGE_SIZE),
    100
  );

  return (
    <section className="find-issues-page">
      <div className="find-issues-heading">
        <p className="section-eyebrow">✦ DISCOVER PROJECTS</p>
        <h1>
          Find <span>Open Issues</span>
        </h1>
        <p className="find-issues-description">
          Discover real open-source opportunities on GitHub and take your
          first step toward contributing.
        </p>
      </div>

      <form className="issue-search-panel" onSubmit={handleSearch}>
        <label className="issue-search-label" htmlFor="issue-keyword">
          Search by keyword or technology
        </label>

        <div className="issue-search-row">
          <span className="issue-search-icon" aria-hidden="true">
            ⌕
          </span>

          <input
            id="issue-keyword"
            type="search"
            value={keyword}
            onChange={(event) => setKeyword(event.target.value)}
            placeholder="Try React, Python, documentation..."
          />

          <button className="issue-search-button" type="submit">
            Search <span>→</span>
          </button>
        </div>

        <div className="issue-filters">
          <label className="beginner-filter">
            <input
              type="checkbox"
              checked={beginnerOnly}
              onChange={(event) => setBeginnerOnly(event.target.checked)}
            />
            <span className="custom-checkbox">✓</span>
            <span>
              <strong>Beginner-friendly</strong>
              <small>good first issue</small>
            </span>
          </label>

          <button
            className="clear-filters-button"
            type="button"
            onClick={clearFilters}
          >
            Clear filters
          </button>
        </div>
      </form>

      <div className="issue-results-heading">
        <div>
          <h2>Explore opportunities</h2>
          <p>
            {loading
              ? "Searching GitHub..."
              : `${totalCount.toLocaleString("en-IN")} matching issues found`}
          </p>
        </div>

        <span className="live-api-badge">
          <span className="live-api-dot" />
          GitHub Live
        </span>
      </div>

      {loading && (
        <div className="issue-state-card" role="status">
          <div className="issue-loader" />
          <h3>Finding open issues...</h3>
          <p>GitHub se latest matching issues load ho rahe hain.</p>
        </div>
      )}

      {!loading && error && (
        <div className="issue-state-card issue-error-card" role="alert">
          <span className="issue-state-icon">!</span>
          <h3>Issues load nahi ho paaye</h3>
          <p>{error}</p>
          <button
            className="issue-retry-button"
            type="button"
            onClick={() => setRetryCount((count) => count + 1)}
          >
            Try again
          </button>
        </div>
      )}

      {!loading && !error && issues.length === 0 && (
        <div className="issue-state-card">
          <span className="issue-state-icon">⌕</span>
          <h3>No matching issues found</h3>
          <p>
            Keyword change karo ya beginner-friendly filter hata kar dobara
            search karo.
          </p>
          <button
            className="issue-retry-button"
            type="button"
            onClick={clearFilters}
          >
            Show more issues
          </button>
        </div>
      )}

      {!loading && !error && issues.length > 0 && (
        <>
          <div className="issue-results-list">
            {issues.map((issue) => {
              const description = cleanDescription(issue.body || "");

              return (
                <article className="github-issue-card" key={issue.id}>
                  <div className="github-issue-topline">
                    <span className="github-issue-number">
                      #{issue.number}
                    </span>
                    <span className="github-issue-status">
                      <span /> Open
                    </span>
                  </div>

                  <h3>{issue.title}</h3>

                  <p className="github-repository-name">
                    <span aria-hidden="true">⌘</span>{" "}
                    {getRepositoryName(issue.repository_url)}
                  </p>

                  {description && (
                    <p className="github-issue-description">
                      {description.slice(0, 220)}
                      {description.length > 220 ? "..." : ""}
                    </p>
                  )}

                  <div className="github-issue-labels">
                    {(issue.labels || []).slice(0, 4).map((label) => (
                      <span
                        className="github-label"
                        key={`${issue.id}-${label.id || label.name}`}
                      >
                        {label.name}
                      </span>
                    ))}
                  </div>

                  <div className="github-issue-meta">
                    <span>
                      By <strong>{issue.user?.login || "GitHub user"}</strong>
                    </span>
                    <span>Updated {formatDate(issue.updated_at)}</span>
                  </div>

                  <div className="github-issue-actions">
                    <button
                      className="github-issue-link"
                      type="button"
                      onClick={() => handleSolveIssue(issue)}
                    >
                      Analyze This Issue <span>↗</span>
                    </button>

                    <a
                      className="github-issue-link"
                      href={issue.html_url}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      View issue on GitHub <span>↗</span>
                    </a>
                  </div>
                </article>
              );
            })}
          </div>

          <div className="issue-pagination">
            <button
              type="button"
              disabled={page <= 1 || loading}
              onClick={() => setPage((current) => current - 1)}
            >
              ← Previous
            </button>

            <span>
              Page <strong>{page}</strong>
              {totalPages > 0 ? ` of ${totalPages}` : ""}
            </span>

            <button
              type="button"
              disabled={page >= totalPages || loading}
              onClick={() => setPage((current) => current + 1)}
            >
              Next →
            </button>
          </div>
        </>
      )}
    </section>
  );
}

export default FindIssues;
